# snake

Hey,

This is the code for the snake game based on my medium article 
https://medium.com/p/7b1479c3339e/

You can find a live demo of snake here
https://snake-bouygtlmzn.now.sh/
